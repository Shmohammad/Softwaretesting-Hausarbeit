package de.hsb.softwaretesting;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;

// API-Tests gegen die laufende App. Die erwarteten Werte kommen aus dem README,
// nicht aus dem, was die App aktuell macht. Deshalb schlagen die Tests fehl und zeigen damit die Fehler (F-01, F-03, F-05).


// App vorher starten: npm run db:seed und npm run dev

@DisplayName("Campus Tech Shop - anforderungsbasierte API-Tests")
class CampusTechShopBugTest {

    @BeforeAll
    static void configureRestAssured() {
        RestAssured.baseURI = System.getProperty("shop.baseUrl", "http://localhost:3001");
    }

    // F-01: CAMPUS10 soll 10 % geben (laut README). Produkt 189,00 EUR -> 18,90 EUR Rabatt.
    @Test
    @DisplayName("F-01: CAMPUS10 muss 10 Prozent Rabatt geben")
    void campus10GrantsTenPercentDiscount() {
        String requestBody = """
            {
              "items": [
                { "productId": "portable-monitor", "quantity": 1 }
              ],
              "discountCode": "CAMPUS10"
            }
            """;

        // Den Statuscode prüfe ich hier nicht, der Rabatt steht so oder so im Body
        Response response = given()
                .contentType(ContentType.JSON)
                .body(requestBody)
                .when()
                .post("/api/cart/validate")
                .then()
                .extract().response();

        int subtotalCents = response.path("totals.subtotalCents");
        int discountCents = response.path("totals.discountCents");

        int expectedDiscount = (int) Math.round(subtotalCents * 0.10); // 10 %

        assertEquals(
                expectedDiscount,
                discountCents,
                "CAMPUS10 muss 10 % Rabatt geben. Erwartet "
                        + expectedDiscount + " Cent, tatsaechlich " + discountCents
                        + " Cent (entspricht nur " + Math.round(discountCents * 100.0 / subtotalCents)
                        + " %).");
    }

    // F-03: webcam-light hat nur 2 auf Lager. Bestellung über 3 muss abgelehnt werden,sonst wird der Bestand negativ.


    @Test
    @DisplayName("F-03: Bestellung ueber dem Lagerbestand muss abgelehnt werden")
    void orderAboveStockIsRejected() {
        String requestBody = """
            {
              "customerName": "Testkundin",
              "email": "testkundin@example.com",
              "items": [
                { "productId": "webcam-light", "quantity": 3 }
              ]
            }
            """;

        int statusCode = given()
                .contentType(ContentType.JSON)
                .body(requestBody)
                .when()
                .post("/api/orders")
                .then()
                .extract().statusCode();

        assertEquals(
                422,
                statusCode,
                "Eine Bestellung ueber dem Lagerbestand (3 von 2) muss mit HTTP 422 "
                        + "abgelehnt werden, damit der Bestand nicht negativ wird. "
                        + "Tatsaechlicher Statuscode: " + statusCode + ".");
    }

    // F-05: Löschen ohne Login darf nicht gehen. Ohne Token sollte 401 kommen.


    @Test
    @DisplayName("F-05: Produkt loeschen ohne Admin-Login muss verweigert werden")
    void deleteWithoutAdminLoginIsForbidden() {
        int statusCode = given()
                .when()
                .delete("/api/admin/products/marker-set")
                .then()
                .extract().statusCode();

        assertEquals(
                401,
                statusCode,
                "Das Loeschen eines Produkts ohne Admin-Login muss mit HTTP 401 "
                        + "verweigert werden. Tatsaechlicher Statuscode: " + statusCode + ".");
    }
}