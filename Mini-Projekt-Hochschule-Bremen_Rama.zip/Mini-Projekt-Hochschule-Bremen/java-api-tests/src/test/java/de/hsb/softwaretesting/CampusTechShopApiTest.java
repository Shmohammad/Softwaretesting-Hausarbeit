package de.hsb.softwaretesting;

import io.restassured.RestAssured;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.notNullValue;

class CampusTechShopApiTest {

    @BeforeAll
    static void configureRestAssured() {
        RestAssured.baseURI = System.getProperty("shop.baseUrl", "http://localhost:3001");
    }

    @Test
    @DisplayName("Produktliste enthaelt Seed-Produkte")
    void productListContainsSeededProducts() {
        given()
            .when()
                .get("/api/products")
            .then()
                .statusCode(200)
                .body("products.size()", greaterThan(0))
                .body("products[0].id", notNullValue())
                .body("products[0].priceCents", greaterThan(0));
    }

    @Test
    @DisplayName("Gueltiger Warenkorb wird akzeptiert")
    void validCartIsAccepted() {
        given()
            .contentType("application/json")
            .body("""
                {
                  "items": [
                    { "productId": "testing-book", "quantity": 1 }
                  ],
                  "discountCode": "CAMPUS10"
                }
                """)
            .when()
                .post("/api/cart/validate")
            .then()
                .statusCode(200)
                .body("valid", org.hamcrest.Matchers.equalTo(true))
                .body("totals.totalCents", greaterThan(0));
    }
}
