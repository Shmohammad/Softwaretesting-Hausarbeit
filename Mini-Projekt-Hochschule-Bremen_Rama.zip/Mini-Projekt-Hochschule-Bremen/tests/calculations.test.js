import { describe, it, expect } from 'vitest';
import {
    calculateDiscountCents,
    calculateShippingCents,
    calculateTaxCents,
    calculateCartTotals
} from '../server/calculations.js';

// Unit-Tests für die Berechnungen in calculations.js (ohne Server/DB).
// Erwartete Werte kommen aus dem README. Die fehlerhaften Stellen (F-01, F-02)
// lassen die Tests rot werden. Starten mit: npm test

describe('calculateDiscountCents (Rabatt)', () => {
    it('F-01: CAMPUS10 soll 10 % geben', () => {
        const subtotalCents = 10000; // 100,00 EUR
        const discountCents = calculateDiscountCents(subtotalCents, 'CAMPUS10');
        expect(discountCents).toBe(1000); // App gibt nur 500 (5 %) -> rot
    });

    it('CAMPUS10 auch klein geschrieben / mit Leerzeichen', () => {
        expect(calculateDiscountCents(10000, '  campus10 ')).toBe(1000);
    });

    it('Falscher Code -> kein Rabatt', () => {
        expect(calculateDiscountCents(10000, 'WUMMS')).toBe(0);
        expect(calculateDiscountCents(10000, '')).toBe(0);
    });
});

describe('calculateShippingCents (Versand)', () => {
    // gratis ab 75,00 EUR, sonst 4,90 EUR -> Grenzwerte testen
    it('74,99 EUR -> 4,90 EUR', () => {
        expect(calculateShippingCents(7499)).toBe(490);
    });
    it('75,00 EUR -> gratis', () => {
        expect(calculateShippingCents(7500)).toBe(0);
    });
    it('75,01 EUR -> gratis', () => {
        expect(calculateShippingCents(7501)).toBe(0);
    });
});

describe('calculateTaxCents (MwSt)', () => {
    it('19 % auf rabattierte Summe', () => {
        expect(calculateTaxCents(9000)).toBe(1710); // 19 % von 9000
    });
});

describe('calculateCartTotals (Gesamt)', () => {
    // Monitor 189,00 EUR + CAMPUS10. Soll: Rabatt 1890, MwSt 3232, Gesamt 20242
    it('F-01/F-02: Gesamtbetrag mit CAMPUS10', () => {
        const items = [{ priceCents: 18900, quantity: 1 }];
        const totals = calculateCartTotals(items, 'CAMPUS10');
        expect(totals.discountCents).toBe(1890); // App: 945  -> F-01
        expect(totals.taxCents).toBe(3232);      // App: 3591 -> F-02
        expect(totals.totalCents).toBe(20242);   // App: 21546
    });
});