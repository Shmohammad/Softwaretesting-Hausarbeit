import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Boxes,
  CheckCircle2,
  LogIn,
  LogOut,
  Minus,
  PackagePlus,
  Plus,
  Search,
  Settings,
  ShoppingCart,
  Trash2
} from 'lucide-react';
import './styles.css';

const emptyProduct = {
  name: '',
  category: 'Zubehoer',
  description: '',
  priceCents: 1000,
  stock: 1,
  imageUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=900&q=80',
  featured: false
};

function euro(cents) {
  return new Intl.NumberFormat('de-DE', {
    style: 'currency',
    currency: 'EUR'
  }).format(cents / 100);
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: {
      'Content-Type': 'application/json',
      ...(options.token ? { Authorization: `Bearer ${options.token}` } : {})
    },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined
  });

  if (response.status === 204) {
    return null;
  }

  const payload = await response.json();
  if (!response.ok) {
    const error = new Error(payload.message || 'Anfrage fehlgeschlagen.');
    error.payload = payload;
    throw error;
  }

  return payload;
}

function Header({ cartCount, currentView, setCurrentView, adminUser, onLogout }) {
  return (
    <header className="app-header">
      <div className="brand">
        <div className="brand-mark">CT</div>
        <div>
          <strong>Campus Tech Shop</strong>
          <span>Testobjekt fuer Softwaretesting</span>
        </div>
      </div>
      <nav aria-label="Hauptnavigation">
        <button className={currentView === 'shop' ? 'active' : ''} onClick={() => setCurrentView('shop')}>
          <ShoppingCart size={18} /> Shop
        </button>
        <button className={currentView === 'admin' ? 'active' : ''} onClick={() => setCurrentView('admin')}>
          <Settings size={18} /> Admin
        </button>
        {adminUser && (
          <button onClick={onLogout} title="Admin abmelden">
            <LogOut size={18} /> Logout
          </button>
        )}
      </nav>
      <div className="cart-pill" aria-label={`${cartCount} Artikel im Warenkorb`}>
        <ShoppingCart size={18} />
        <span>{cartCount}</span>
      </div>
    </header>
  );
}

function ProductCard({ product, onAdd, onInspect }) {
  return (
    <article className="product-card">
      <button className="image-button" onClick={() => onInspect(product)} aria-label={`${product.name} ansehen`}>
        <img src={product.imageUrl} alt="" />
      </button>
      <div className="product-body">
        <div className="product-meta">
          <span>{product.category}</span>
          {product.featured && <strong>Empfohlen</strong>}
        </div>
        <h3>{product.name}</h3>
        <p>{product.description}</p>
        <div className="product-footer">
          <div>
            <strong>{euro(product.priceCents)}</strong>
            <small>{product.stock > 1 ? `${product.stock} verfuegbar` : 'Ausverkauft'}</small>
          </div>
          <button className="primary icon-button" onClick={() => onAdd(product)} disabled={product.stock < 1}>
            <Plus size={18} /> Hinzufuegen
          </button>
        </div>
      </div>
    </article>
  );
}

function CartPanel({ cart, products, setCart, discountCode, setDiscountCode, totals, validationErrors, onCheckout }) {
  const cartProducts = cart
    .map((item) => ({
      ...item,
      product: products.find((product) => product.id === item.productId)
    }))
    .filter((item) => item.product);

  function changeQuantity(productId, delta) {
    setCart((items) =>
      items.map((item) =>
        item.productId === productId ? { ...item, quantity: Math.max(0, item.quantity + delta) } : item
      )
    );
  }

  function remove(productId) {
    setCart((items) => items.filter((item) => item.productId !== productId));
  }

  return (
    <aside className="cart-panel" aria-label="Warenkorb">
      <div className="panel-title">
        <ShoppingCart size={20} />
        <h2>Warenkorb</h2>
      </div>
      {cartProducts.length === 0 ? (
        <p className="muted">Noch keine Produkte ausgewaehlt.</p>
      ) : (
        <div className="cart-items">
          {cartProducts.map(({ product, quantity }) => (
            <div className="cart-row" key={product.id}>
              <div>
                <strong>{product.name}</strong>
                <span>{euro(product.priceCents)} pro Stueck</span>
              </div>
              <div className="quantity">
                <button aria-label={`${product.name} reduzieren`} onClick={() => changeQuantity(product.id, -1)}>
                  <Minus size={16} />
                </button>
                <span>{quantity}</span>
                <button aria-label={`${product.name} erhoehen`} onClick={() => changeQuantity(product.id, 1)}>
                  <Plus size={16} />
                </button>
                <button aria-label={`${product.name} entfernen`} onClick={() => remove(product.id)}>
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <label className="field">
        Rabattcode
        <input value={discountCode} onChange={(event) => setDiscountCode(event.target.value)} placeholder="CAMPUS10" />
      </label>

      {validationErrors.length > 0 && (
        <div className="error-box" role="alert">
          {validationErrors.map((error) => (
            <p key={error}>{error}</p>
          ))}
        </div>
      )}

      <dl className="totals">
        <div>
          <dt>Zwischensumme</dt>
          <dd>{euro(totals.subtotalCents)}</dd>
        </div>
        <div>
          <dt>Rabatt</dt>
          <dd>-{euro(totals.discountCents)}</dd>
        </div>
        <div>
          <dt>Versand</dt>
          <dd>{euro(totals.shippingCents)}</dd>
        </div>
        <div>
          <dt>MwSt.</dt>
          <dd>{euro(totals.taxCents)}</dd>
        </div>
        <div className="total-line">
          <dt>Gesamt</dt>
          <dd>{euro(totals.totalCents)}</dd>
        </div>
      </dl>
      <button className="primary checkout" disabled={cartProducts.length === 0} onClick={onCheckout}>
        <CheckCircle2 size={18} /> Zur Kasse
      </button>
    </aside>
  );
}

function CheckoutDialog({ cart, discountCode, onClose, onCompleted }) {
  const [customerName, setCustomerName] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setLoading(true);
    setError('');
    try {
      const payload = await api('/api/orders', {
        method: 'POST',
        body: {
          customerName,
          email,
          discountCode,
          items: cart
        }
      });
      setOrder(payload);
      onCompleted();
    } catch (requestError) {
      setError(requestError.payload?.errors?.join(' ') || requestError.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="dialog-backdrop">
      <section className="dialog" role="dialog" aria-modal="true" aria-labelledby="checkout-title">
        <button className="close-button" onClick={onClose} aria-label="Dialog schliessen">
          x
        </button>
        {order ? (
          <div className="success-state">
            <CheckCircle2 size={42} />
            <h2 id="checkout-title">Bestellung angelegt</h2>
            <p>Bestellnummer: {order.orderId}</p>
            <strong>{euro(order.totals.totalCents)}</strong>
          </div>
        ) : (
          <form onSubmit={submit} className="checkout-form">
            <h2 id="checkout-title">Checkout</h2>
            <label className="field">
              Name
              <input value={customerName} onChange={(event) => setCustomerName(event.target.value)} required />
            </label>
            <label className="field">
              E-Mail
              <input value={email} onChange={(event) => setEmail(event.target.value)} required />
            </label>
            {error && <p className="form-error">{error}</p>}
            <button className="primary" disabled={loading}>
              {loading ? 'Wird gespeichert...' : 'Bestellung abschliessen'}
            </button>
          </form>
        )}
      </section>
    </div>
  );
}

function ProductDialog({ product, onClose, onAdd }) {
  if (!product) return null;

  return (
    <div className="dialog-backdrop">
      <section className="dialog product-dialog" role="dialog" aria-modal="true" aria-labelledby="product-title">
        <button className="close-button" onClick={onClose} aria-label="Dialog schliessen">
          x
        </button>
        <img src={product.imageUrl} alt="" />
        <div>
          <span className="tag">{product.category}</span>
          <h2 id="product-title">{product.name}</h2>
          <p>{product.description}</p>
          <p className="stock-note">
            {product.stock <= 2 ? 'Nur noch sehr wenige verfuegbar.' : `${product.stock} Stueck verfuegbar.`}
          </p>
          <button className="primary" onClick={() => onAdd(product)}>
            <Plus size={18} /> In den Warenkorb
          </button>
        </div>
      </section>
    </div>
  );
}

function ShopView() {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [cart, setCart] = useState(() => JSON.parse(localStorage.getItem('campus-cart') ?? '[]'));
  const [discountCode, setDiscountCode] = useState('');
  const [validation, setValidation] = useState({
    errors: [],
    totals: { subtotalCents: 0, discountCents: 0, shippingCents: 0, taxCents: 0, totalCents: 0 }
  });
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);

  useEffect(() => {
    const params = new URLSearchParams();
    if (search) params.set('search', search);
    if (category) params.set('category', category);
    api(`/api/products?${params}`).then((payload) => setProducts(payload.products));
  }, [search, category]);

  useEffect(() => {
    localStorage.setItem('campus-cart', JSON.stringify(cart));
    api('/api/cart/validate', {
      method: 'POST',
      body: {
        items: cart,
        discountCode
      }
    })
      .then((payload) => setValidation({ errors: payload.errors, totals: payload.totals }))
      .catch((requestError) =>
        setValidation({
          errors: requestError.payload?.errors ?? [requestError.message],
          totals: requestError.payload?.totals ?? validation.totals
        })
      );
  }, [cart, discountCode]);

  const categories = useMemo(() => Array.from(new Set(products.map((product) => product.category))).sort(), [products]);

  function addToCart(product) {
    setCart((items) => {
      const existing = items.find((item) => item.productId === product.id);
      if (existing) {
        return items.map((item) =>
          item.productId === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...items, { productId: product.id, quantity: 1 }];
    });
  }

  return (
    <main className="shop-layout">
      <section className="shop-main">
        <div className="hero">
          <div>
            <span className="eyebrow">Labor, Bibliothek, Zuhause</span>
            <h1>Campus Tech Shop</h1>
            <p>
              Fiktiver Shop fuer Testentwurf, Automatisierung und Fehlermanagement. Rabattcode CAMPUS10 gibt laut
              Spezifikation 10 Prozent Rabatt.
            </p>
          </div>
          <div className="hero-visual">
            <Boxes size={52} />
            <span>Versandkostenfrei ab 75,00 EUR</span>
          </div>
        </div>

        <div className="toolbar">
          <label className="search-field">
            <Search size={18} />
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Produkte suchen"
              aria-label="Produkte suchen"
            />
          </label>
          <select value={category} onChange={(event) => setCategory(event.target.value)} aria-label="Kategorie filtern">
            <option value="">Alle Kategorien</option>
            {categories.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </select>
        </div>

        <div className="product-grid">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} onAdd={addToCart} onInspect={setSelectedProduct} />
          ))}
        </div>
      </section>

      <CartPanel
        cart={cart}
        products={products}
        setCart={setCart}
        discountCode={discountCode}
        setDiscountCode={setDiscountCode}
        totals={validation.totals}
        validationErrors={validation.errors}
        onCheckout={() => setCheckoutOpen(true)}
      />

      {checkoutOpen && (
        <CheckoutDialog
          cart={cart}
          discountCode={discountCode}
          onClose={() => setCheckoutOpen(false)}
          onCompleted={() => setCart([])}
        />
      )}
      <ProductDialog product={selectedProduct} onClose={() => setSelectedProduct(null)} onAdd={addToCart} />
    </main>
  );
}

function AdminView({ adminUser, setAdminUser }) {
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('');
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState(emptyProduct);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const token = localStorage.getItem('campus-admin-token');

  async function loadProducts() {
    if (!token) return;
    const payload = await api('/api/admin/products', { token });
    setProducts(payload.products);
  }

  useEffect(() => {
    loadProducts().catch(() => {});
  }, [token]);

  async function login(event) {
    event.preventDefault();
    setError('');
    try {
      const payload = await api('/api/admin/login', {
        method: 'POST',
        body: { username, password }
      });
      localStorage.setItem('campus-admin-token', payload.token);
      setAdminUser(payload.user);
      setPassword('');
      setMessage('Admin angemeldet.');
    } catch (requestError) {
      setError(requestError.message);
    }
  }

  async function saveProduct(event) {
    event.preventDefault();
    setError('');
    setMessage('');
    try {
      await api('/api/admin/products', {
        method: 'POST',
        token,
        body: form
      });
      setForm(emptyProduct);
      setMessage('Produkt gespeichert.');
      await loadProducts();
    } catch (requestError) {
      setError(requestError.message);
    }
  }

  async function updateProduct(product, patch) {
    const updated = { ...product, ...patch };
    await api(`/api/admin/products/${product.id}`, {
      method: 'PUT',
      token,
      body: updated
    });
    await loadProducts();
  }

  async function deleteProduct(productId) {
    await api(`/api/admin/products/${productId}`, {
      method: 'DELETE',
      token
    });
    setProducts((items) => items.filter((product) => product.id !== productId));
  }

  if (!adminUser && !token) {
    return (
      <main className="admin-page">
        <form className="login-card" onSubmit={login}>
          <LogIn size={32} />
          <h1>Admin Login</h1>
          <p>Demo-Zugang: admin / Campus2026!</p>
          <label className="field">
            Benutzername
            <input value={username} onChange={(event) => setUsername(event.target.value)} />
          </label>
          <label className="field">
            Passwort
            <input value={password} onChange={(event) => setPassword(event.target.value)} type="password" />
          </label>
          {error && <p className="form-error">{error}</p>}
          <button className="primary">Anmelden</button>
        </form>
      </main>
    );
  }

  return (
    <main className="admin-page">
      <section className="admin-grid">
        <form className="admin-form" onSubmit={saveProduct}>
          <div className="panel-title">
            <PackagePlus size={20} />
            <h1>Produkt anlegen</h1>
          </div>
          <label className="field">
            Name
            <input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} />
          </label>
          <label className="field">
            Kategorie
            <input value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value })} />
          </label>
          <label className="field">
            Beschreibung
            <textarea
              value={form.description}
              onChange={(event) => setForm({ ...form, description: event.target.value })}
            />
          </label>
          <div className="split-fields">
            <label className="field">
              Preis in Cent
              <input
                value={form.priceCents}
                onChange={(event) => setForm({ ...form, priceCents: Number(event.target.value) })}
                type="number"
              />
            </label>
            <label className="field">
              Bestand
              <input
                value={form.stock}
                onChange={(event) => setForm({ ...form, stock: Number(event.target.value) })}
                type="number"
              />
            </label>
          </div>
          <label className="field">
            Bild-URL
            <input value={form.imageUrl} onChange={(event) => setForm({ ...form, imageUrl: event.target.value })} />
          </label>
          <label className="checkbox-field">
            <input
              checked={form.featured}
              onChange={(event) => setForm({ ...form, featured: event.target.checked })}
              type="checkbox"
            />
            Empfohlen anzeigen
          </label>
          {message && <p className="success-text">{message}</p>}
          {error && <p className="form-error">{error}</p>}
          <button className="primary">Produkt speichern</button>
        </form>

        <section className="admin-list">
          <h1>Produkte verwalten</h1>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Kategorie</th>
                  <th>Preis</th>
                  <th>Bestand</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {products.map((product) => (
                  <tr key={product.id}>
                    <td>{product.name}</td>
                    <td>{product.category}</td>
                    <td>
                      <input
                        aria-label={`${product.name} Preis`}
                        type="number"
                        value={product.priceCents}
                        onChange={(event) => updateProduct(product, { priceCents: Number(event.target.value) })}
                      />
                    </td>
                    <td>
                      <input
                        aria-label={`${product.name} Bestand`}
                        type="number"
                        value={product.stock}
                        onChange={(event) => updateProduct(product, { stock: Number(event.target.value) })}
                      />
                    </td>
                    <td>{product.active ? 'Aktiv' : 'Inaktiv'}</td>
                    <td>
                      <button aria-label={`${product.name} loeschen`} onClick={() => deleteProduct(product.id)}>
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </section>
    </main>
  );
}

function App() {
  const [currentView, setCurrentView] = useState('shop');
  const [adminUser, setAdminUser] = useState(null);
  const [cartCount, setCartCount] = useState(() =>
    JSON.parse(localStorage.getItem('campus-cart') ?? '[]').reduce((sum, item) => sum + item.quantity, 0)
  );

  useEffect(() => {
    const update = () => {
      setCartCount(JSON.parse(localStorage.getItem('campus-cart') ?? '[]').reduce((sum, item) => sum + item.quantity, 0));
    };
    window.addEventListener('storage', update);
    const timer = window.setInterval(update, 300);
    return () => {
      window.removeEventListener('storage', update);
      window.clearInterval(timer);
    };
  }, []);

  function logout() {
    localStorage.removeItem('campus-admin-token');
    setAdminUser(null);
  }

  return (
    <>
      <Header
        cartCount={cartCount}
        currentView={currentView}
        setCurrentView={setCurrentView}
        adminUser={adminUser}
        onLogout={logout}
      />
      {currentView === 'shop' ? <ShopView /> : <AdminView adminUser={adminUser} setAdminUser={setAdminUser} />}
    </>
  );
}

createRoot(document.getElementById('root')).render(<App />);
