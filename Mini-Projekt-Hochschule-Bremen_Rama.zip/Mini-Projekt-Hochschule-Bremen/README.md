# Campus Tech Shop

Mini-Projekt fuer die Zwischenpruefung im Modul Softwaretesting.

Dies ist ein fiktiver Webshop fuer eine Hausarbeit im Modul Softwaretesting. Die Anwendung ist bewusst klein gehalten, aber realistisch genug, damit Du Unit-, Integrations-, API- und Systemtests planen und automatisieren kannst.

Die Anwendung enthaelt absichtlich fachliche und technische Abweichungen vom beschriebenen Sollverhalten. Dein Ziel ist es, diese Abweichungen durch systematisches Testen zu finden, zu dokumentieren und zu bewerten.

## Start

Du brauchst Node.js 22 oder neuer.

```bash
npm install
npm run db:seed
npm run dev
```

Danach kannst Du die Anwendung im Browser unter `http://127.0.0.1:5173` oeffnen.

## Wichtige Skripte

```bash
npm run dev       # startet Backend und Frontend
npm run db:seed   # setzt die SQLite-Datenbank auf Dummy-Daten zurueck
npm test          # fuehrt die Java-API-Beispieltests aus, wenn die API laeuft
```

Die Beispieltests fuer Deine eigene Automatisierung liegen im Ordner `java-api-tests` und nutzen JUnit 5 mit REST Assured.

## API-Tests mit IntelliJ

Im Ordner `api-tests` findest Du die Datei `requests.http`. Diese Datei kannst Du direkt in IntelliJ oeffnen und einzelne API-Requests ausfuehren. Das ist gut geeignet, um Endpunkte schnell zu erkunden, Antworten zu vergleichen und erste Erwartungen zu pruefen.

Starte vorher die Anwendung:

```bash
npm run db:seed
npm run dev
```

Danach kannst Du in IntelliJ in `api-tests/requests.http` auf die Run-Symbole neben den Requests klicken.

## Automatisierte API-Tests mit JUnit

Im Ordner `java-api-tests` findest Du ein kleines Maven-Projekt mit JUnit 5 und REST Assured. Damit kannst Du automatisierte API-Tests in Java schreiben.

Starte in einem Terminal die Anwendung:

```bash
npm run db:seed
npm run dev
```

Fuehre danach in einem zweiten Terminal die Java-Tests aus:

```bash
cd java-api-tests
mvn test
```

In IntelliJ kannst Du den Ordner `java-api-tests` auch als Maven-Projekt importieren und die Tests direkt aus der IDE starten.

## Fachliches Sollverhalten

- Du kannst Produkte anzeigen, suchen, nach Kategorie filtern und in den Warenkorb legen.
- Der Warenkorb darf nur bestellbare Produkte mit positiver Menge enthalten.
- Eine Bestellung darf nur mit Name, gueltiger E-Mail-Adresse und mindestens einem Warenkorb-Artikel angelegt werden.
- Der Rabattcode `CAMPUS10` reduziert die Zwischensumme um 10 Prozent.
- Ab 75,00 EUR Zwischensumme ist der Versand kostenlos, darunter betraegt er 4,90 EUR.
- Die Mehrwertsteuer betraegt 19 Prozent und soll auf die rabattierte Warensumme berechnet werden.
- Lagerbestand darf durch eine Bestellung nicht negativ werden.
- Nicht vorhandene Produkte sollen als Fehler behandelt werden.
- Admin-Funktionen duerfen nur nach erfolgreichem Admin-Login genutzt werden.
- Als Admin kannst Du Produkte anlegen, bearbeiten, deaktivieren und Lagerbestaende korrigieren.
- Produktpreise und Lagerbestaende duerfen nicht negativ sein.

## Admin-Zugang

- Benutzername: `admin`
- Passwort: `Campus2026!`

## Technologie

- Frontend: React mit Vite
- Backend: Express
- Datenbank: SQLite
- Empfohlene API-Tests fuer Deine Abgabe: IntelliJ HTTP Client, JUnit 5, REST Assured

Die SQLite-Datei wird unter `server/data/campus-shop.sqlite` erzeugt und ist nicht Teil des Git-Repositories.

## Hinweise fuer Deine Testarbeit

Die vorhandenen Tests und HTTP-Requests sind nur Beispiele. Diese Beispiele decken bewusst nicht alle Anforderungen ab. Entwirf zusaetzliche Tests, die Normalfaelle, Grenzwerte, Fehlersituationen und rollenbezogene Szenarien pruefen.
