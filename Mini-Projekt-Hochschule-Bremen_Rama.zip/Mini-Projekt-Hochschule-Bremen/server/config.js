import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export const PORT = Number(process.env.PORT ?? 3001);
export const DB_FILE = process.env.DB_FILE ?? path.join(__dirname, 'data', 'campus-shop.sqlite');
export const ADMIN_USER = process.env.ADMIN_USER ?? 'admin';
export const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD ?? 'Campus2026!';
export const ADMIN_TOKEN = process.env.ADMIN_TOKEN ?? 'admin-demo-token';
