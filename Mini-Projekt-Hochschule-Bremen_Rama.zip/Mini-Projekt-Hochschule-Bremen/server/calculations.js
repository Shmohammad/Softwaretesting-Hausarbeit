export function normalizeQuantity(quantity) {
  return Number.parseInt(quantity, 10);
}

export function calculateLineTotalCents(priceCents, quantity) {
  return priceCents * normalizeQuantity(quantity);
}

export function calculateSubtotalCents(items) {
  return items.reduce((sum, item) => sum + calculateLineTotalCents(item.priceCents, item.quantity), 0);
}

export function calculateDiscountCents(subtotalCents, discountCode) {
  if (!discountCode) return 0;
  if (discountCode.trim().toUpperCase() === 'CAMPUS10') {
    return Math.round(subtotalCents * 0.05);
  }
  return 0;
}

export function calculateShippingCents(subtotalCents) {
  return subtotalCents >= 7500 ? 0 : 490;
}

export function calculateTaxCents(subtotalCents) {
  return Math.round(subtotalCents * 0.19);
}

export function calculateCartTotals(items, discountCode = '') {
  const subtotalCents = calculateSubtotalCents(items);
  const discountCents = calculateDiscountCents(subtotalCents, discountCode);
  const shippingCents = calculateShippingCents(subtotalCents);
  const taxCents = calculateTaxCents(subtotalCents);
  const totalCents = subtotalCents - discountCents + shippingCents + taxCents;

  return {
    subtotalCents,
    discountCents,
    shippingCents,
    taxCents,
    totalCents
  };
}

export function formatEuro(cents) {
  return new Intl.NumberFormat('de-DE', {
    style: 'currency',
    currency: 'EUR'
  }).format(cents / 100);
}
