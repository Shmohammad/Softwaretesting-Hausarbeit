import { DB_FILE } from './config.js';
import { openDatabase, seedDatabase } from './db.js';

const db = openDatabase(DB_FILE);
seedDatabase(db);
db.close();

console.log(`SQLite-Datenbank wurde neu befuellt: ${DB_FILE}`);
