import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';

export function openDatabase(filePath) {
  if (filePath !== ':memory:') {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
  }

  const db = new Database(filePath);
  db.pragma('foreign_keys = ON');
  migrate(db);
  return db;
}

export function migrate(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      priceCents INTEGER NOT NULL,
      stock INTEGER NOT NULL,
      imageUrl TEXT NOT NULL,
      featured INTEGER NOT NULL DEFAULT 0,
      active INTEGER NOT NULL DEFAULT 1,
      createdAt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      customerName TEXT NOT NULL,
      email TEXT NOT NULL,
      discountCode TEXT,
      subtotalCents INTEGER NOT NULL,
      discountCents INTEGER NOT NULL,
      shippingCents INTEGER NOT NULL,
      taxCents INTEGER NOT NULL,
      totalCents INTEGER NOT NULL,
      createdAt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      orderId TEXT NOT NULL,
      productId TEXT NOT NULL,
      quantity INTEGER NOT NULL,
      priceCents INTEGER NOT NULL,
      FOREIGN KEY (orderId) REFERENCES orders(id) ON DELETE CASCADE,
      FOREIGN KEY (productId) REFERENCES products(id)
    );
  `);
}

export function clearDatabase(db) {
  db.exec(`
    DELETE FROM order_items;
    DELETE FROM orders;
    DELETE FROM products;
  `);
}

export function seedDatabase(db) {
  clearDatabase(db);

  const products = [
    {
      id: 'usb-c-dock-pro',
      name: 'USB-C Dock Pro',
      category: 'Zubehoer',
      description: 'Kompaktes Dock mit HDMI, Ethernet und vier USB-Anschluessen fuer den Campus-Arbeitsplatz.',
      priceCents: 6990,
      stock: 8,
      imageUrl: 'https://images.unsplash.com/photo-1625842268584-8f3296236761?auto=format&fit=crop&w=900&q=80',
      featured: 1
    },
    {
      id: 'noise-cancel-headset',
      name: 'Focus Headset',
      category: 'Audio',
      description: 'Leichtes Headset mit aktiver Geraeuschunterdrueckung fuer Online-Vorlesungen und Lerngruppen.',
      priceCents: 8990,
      stock: 5,
      imageUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80',
      featured: 1
    },
    {
      id: 'testing-book',
      name: 'Praxisbuch Softwaretesting',
      category: 'Buecher',
      description: 'Ein kompaktes Begleitbuch zu Testentwurf, Teststufen und Fehlermanagement.',
      priceCents: 3490,
      stock: 12,
      imageUrl: 'https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&w=900&q=80',
      featured: 0
    },
    {
      id: 'portable-monitor',
      name: 'Mobiler Zweitmonitor',
      category: 'Hardware',
      description: '15-Zoll-Display fuer Pair Programming, Praesentationen und mobile Arbeitsplaetze.',
      priceCents: 18900,
      stock: 3,
      imageUrl: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=900&q=80',
      featured: 1
    },
    {
      id: 'mechanical-keyboard',
      name: 'Mechanische Tastatur Campus',
      category: 'Hardware',
      description: 'Kompakte Tastatur mit leisen Switches und deutschem Layout.',
      priceCents: 7990,
      stock: 7,
      imageUrl: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=80',
      featured: 0
    },
    {
      id: 'notebook-stand',
      name: 'Notebook-Staender Aluminium',
      category: 'Zubehoer',
      description: 'Stabiler Staender fuer ergonomisches Arbeiten im Labor oder zu Hause.',
      priceCents: 2990,
      stock: 15,
      imageUrl: 'https://images.unsplash.com/photo-1616627984384-dc0b68b719e6?auto=format&fit=crop&w=900&q=80',
      featured: 0
    },
    {
      id: 'webcam-light',
      name: 'Webcam Light Kit',
      category: 'Audio',
      description: 'Kleine USB-Leuchte fuer klare Bilder in Remote-Pruefungen und Projektmeetings.',
      priceCents: 2490,
      stock: 2,
      imageUrl: 'https://images.unsplash.com/photo-1587614382346-4ec70e388b28?auto=format&fit=crop&w=900&q=80',
      featured: 0
    },
    {
      id: 'campus-backpack',
      name: 'Campus Rucksack 22L',
      category: 'Alltag',
      description: 'Wasserabweisender Rucksack mit Laptopfach, Kabeltasche und reflektierenden Details.',
      priceCents: 5490,
      stock: 9,
      imageUrl: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80',
      featured: 0
    },
    {
      id: 'privacy-screen',
      name: 'Privacy Screen 14 Zoll',
      category: 'Zubehoer',
      description: 'Blickschutzfilter fuer konzentriertes Arbeiten in Bibliothek und Bahn.',
      priceCents: 3990,
      stock: 4,
      imageUrl: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=80',
      featured: 0
    },
    {
      id: 'arduino-kit',
      name: 'IoT Starter Kit',
      category: 'Labor',
      description: 'Sensoren, Mikrocontroller und Steckbrett fuer Laboruebungen und Prototypen.',
      priceCents: 6490,
      stock: 6,
      imageUrl: 'https://images.unsplash.com/photo-1553406830-ef2513450d76?auto=format&fit=crop&w=900&q=80',
      featured: 1
    },
    {
      id: 'marker-set',
      name: 'Whiteboard Marker Set',
      category: 'Alltag',
      description: 'Vier farbige Marker fuer Testfallentwurf, Retrospektiven und Gruppenarbeit.',
      priceCents: 790,
      stock: 25,
      imageUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=900&q=80',
      featured: 0
    }
  ];

  const insert = db.prepare(`
    INSERT INTO products (id, name, category, description, priceCents, stock, imageUrl, featured, active)
    VALUES (@id, @name, @category, @description, @priceCents, @stock, @imageUrl, @featured, 1)
  `);

  const transaction = db.transaction(() => {
    for (const product of products) {
      insert.run(product);
    }
  });

  transaction();
}

export function mapProduct(row) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    description: row.description,
    priceCents: row.priceCents,
    stock: row.stock,
    imageUrl: row.imageUrl,
    featured: Boolean(row.featured),
    active: Boolean(row.active),
    createdAt: row.createdAt
  };
}
