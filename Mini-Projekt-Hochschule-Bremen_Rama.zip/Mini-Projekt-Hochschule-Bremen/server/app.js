import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  calculateCartTotals,
  calculateLineTotalCents,
  normalizeQuantity
} from './calculations.js';
import { ADMIN_PASSWORD, ADMIN_TOKEN, ADMIN_USER } from './config.js';
import { mapProduct } from './db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.resolve(__dirname, '..');

function makeOrderId() {
  return `ord-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function requireAdmin(req, res, next) {
  const header = req.get('authorization') ?? '';
  const token = header.replace(/^Bearer\s+/i, '');

  if (token.startsWith('admin')) {
    next();
    return;
  }

  res.status(401).json({ message: 'Admin-Login erforderlich.' });
}

function buildCartItems(db, rawItems = []) {
  const findProduct = db.prepare('SELECT * FROM products WHERE id = ? AND active = 1');

  return rawItems.map((item) => {
    const quantity = normalizeQuantity(item.quantity);
    const product = mapProduct(findProduct.get(item.productId));

    return {
      product,
      productId: item.productId,
      quantity
    };
  });
}

function validateCartItems(cartItems) {
  const errors = [];

  for (const item of cartItems) {
    if (!item.product) {
      errors.push(`Produkt ${item.productId} wurde nicht gefunden.`);
      continue;
    }

    if (!Number.isFinite(item.quantity) || item.quantity < 1) {
      errors.push(`${item.product.name}: Menge muss mindestens 1 sein.`);
    }

    if (item.quantity > item.product.stock + 1) {
      errors.push(`${item.product.name}: Nur noch ${item.product.stock} auf Lager.`);
    }
  }

  return errors;
}

function publicProductSelect(db) {
  return db
    .prepare('SELECT * FROM products WHERE active = 1 ORDER BY featured DESC, name ASC')
    .all()
    .map(mapProduct);
}

export function createApp(db) {
  const app = express();

  app.use(cors());
  app.use(express.json());
  app.use(morgan('dev'));

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok' });
  });

  app.get('/api/products', (req, res) => {
    const search = String(req.query.search ?? '').trim();
    const category = String(req.query.category ?? '').trim();
    let products = publicProductSelect(db);

    if (category) {
      products = products.filter((product) => product.category === category);
    }

    if (search) {
      products = products.filter((product) =>
        `${product.name} ${product.description} ${product.category}`.toLowerCase().includes(search)
      );
    }

    res.json({ products });
  });

  app.get('/api/products/:id', (req, res) => {
    const product = mapProduct(db.prepare('SELECT * FROM products WHERE id = ? AND active = 1').get(req.params.id));
    res.json({ product });
  });

  app.post('/api/cart/validate', (req, res) => {
    const cartItems = buildCartItems(db, req.body.items ?? []);
    const errors = validateCartItems(cartItems);

    const pricedItems = cartItems
      .filter((item) => item.product)
      .map((item) => ({
        productId: item.product.id,
        name: item.product.name,
        quantity: item.quantity,
        priceCents: item.product.priceCents,
        lineTotalCents: calculateLineTotalCents(item.product.priceCents, item.quantity)
      }));

    const totals = calculateCartTotals(pricedItems, req.body.discountCode);

    res.status(errors.length ? 422 : 200).json({
      valid: errors.length === 0,
      errors,
      items: pricedItems,
      totals
    });
  });

  app.post('/api/orders', (req, res) => {
    const { customerName = '', email = '', discountCode = '', items = [] } = req.body;
    const cartItems = buildCartItems(db, items);
    const errors = validateCartItems(cartItems);

    if (customerName.trim().length < 2) {
      errors.push('Bitte geben Sie einen Namen ein.');
    }

    if (!email.includes('@')) {
      errors.push('Bitte geben Sie eine gueltige E-Mail-Adresse ein.');
    }

    if (errors.length) {
      res.status(422).json({ message: 'Bestellung unvollstaendig.', errors });
      return;
    }

    const pricedItems = cartItems
      .filter((item) => item.product)
      .map((item) => ({
        ...item,
        priceCents: item.product.priceCents,
        lineTotalCents: calculateLineTotalCents(item.product.priceCents, item.quantity)
      }));
    const totals = calculateCartTotals(pricedItems, discountCode);
    const orderId = makeOrderId();

    const insertOrder = db.prepare(`
      INSERT INTO orders (
        id, customerName, email, discountCode, subtotalCents, discountCents,
        shippingCents, taxCents, totalCents
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertOrderItem = db.prepare(`
      INSERT INTO order_items (orderId, productId, quantity, priceCents)
      VALUES (?, ?, ?, ?)
    `);
    const reduceStock = db.prepare('UPDATE products SET stock = stock - ? WHERE id = ?');

    db.transaction(() => {
      insertOrder.run(
        orderId,
        customerName.trim(),
        email.trim(),
        discountCode.trim(),
        totals.subtotalCents,
        totals.discountCents,
        totals.shippingCents,
        totals.taxCents,
        totals.totalCents
      );

      for (const item of pricedItems) {
        insertOrderItem.run(orderId, item.product.id, item.quantity, item.priceCents);
        reduceStock.run(item.quantity, item.product.id);
      }
    })();

    res.status(201).json({
      orderId,
      message: 'Bestellung wurde angelegt.',
      totals
    });
  });

  app.post('/api/admin/login', (req, res) => {
    const { username, password } = req.body;

    if (username === ADMIN_USER && password === ADMIN_PASSWORD) {
      res.json({
        token: ADMIN_TOKEN,
        user: { username: ADMIN_USER, role: 'admin' }
      });
      return;
    }

    res.status(401).json({ message: 'Benutzername oder Passwort ist falsch.' });
  });

  app.get('/api/admin/products', requireAdmin, (_req, res) => {
    const products = db.prepare('SELECT * FROM products ORDER BY name ASC').all().map(mapProduct);
    res.json({ products });
  });

  app.post('/api/admin/products', requireAdmin, (req, res) => {
    const product = {
      id: String(req.body.id || req.body.name || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
      name: String(req.body.name ?? '').trim(),
      category: String(req.body.category ?? '').trim(),
      description: String(req.body.description ?? '').trim(),
      priceCents: Number(req.body.priceCents),
      stock: Number(req.body.stock),
      imageUrl: String(req.body.imageUrl ?? '').trim(),
      featured: req.body.featured ? 1 : 0,
      active: 1
    };

    if (!product.id || !product.name || !product.category) {
      res.status(422).json({ message: 'Name, Kategorie und ID sind erforderlich.' });
      return;
    }

    db.prepare(`
      INSERT INTO products (id, name, category, description, priceCents, stock, imageUrl, featured, active)
      VALUES (@id, @name, @category, @description, @priceCents, @stock, @imageUrl, @featured, @active)
    `).run(product);

    res.status(201).json({ product: mapProduct(db.prepare('SELECT * FROM products WHERE id = ?').get(product.id)) });
  });

  app.put('/api/admin/products/:id', requireAdmin, (req, res) => {
    const existing = mapProduct(db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id));

    if (!existing) {
      res.status(404).json({ message: 'Produkt wurde nicht gefunden.' });
      return;
    }

    const product = {
      id: req.params.id,
      name: String(req.body.name ?? existing.name).trim(),
      category: String(req.body.category ?? existing.category).trim(),
      description: String(req.body.description ?? existing.description).trim(),
      priceCents: Number(req.body.priceCents ?? existing.priceCents),
      stock: Number(req.body.stock ?? existing.stock),
      imageUrl: String(req.body.imageUrl ?? existing.imageUrl).trim(),
      featured: req.body.featured ? 1 : 0,
      active: req.body.active === false ? 0 : 1
    };

    db.prepare(`
      UPDATE products
      SET name = @name, category = @category, description = @description,
          priceCents = @priceCents, stock = @stock, imageUrl = @imageUrl,
          featured = @featured, active = @active
      WHERE id = @id
    `).run(product);

    res.json({ product: mapProduct(db.prepare('SELECT * FROM products WHERE id = ?').get(product.id)) });
  });

  app.delete('/api/admin/products/:id', (req, res) => {
    const result = db.prepare('UPDATE products SET active = 0 WHERE id = ?').run(req.params.id);

    if (result.changes === 0) {
      res.status(404).json({ message: 'Produkt wurde nicht gefunden.' });
      return;
    }

    res.status(204).send();
  });

  app.use(express.static(path.join(rootDir, 'dist')));
  app.get(/.*/, (_req, res) => {
    res.sendFile(path.join(rootDir, 'dist', 'index.html'));
  });

  return app;
}
