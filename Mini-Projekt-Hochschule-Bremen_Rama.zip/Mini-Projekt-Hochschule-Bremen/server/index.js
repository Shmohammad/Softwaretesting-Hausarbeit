import { DB_FILE, PORT } from './config.js';
import { openDatabase } from './db.js';
import { createApp } from './app.js';

const db = openDatabase(DB_FILE);
const app = createApp(db);

app.listen(PORT, () => {
  console.log(`Campus Tech Shop API laeuft auf http://127.0.0.1:${PORT}`);
});
