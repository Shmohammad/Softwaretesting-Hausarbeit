# Hausarbeit: Testen des Campus Tech Shop

## Ausgangslage

Du erhaeltst einen fiktiven Webshop mit React-Frontend, Express-Backend und SQLite-Datenbank. Der Shop ist lauffaehig, enthaelt aber absichtlich mehrere Fehler. Deine Aufgabe ist es, diese Fehler mit einem nachvollziehbaren Testvorgehen aufzudecken.

Bearbeitungszeit: 14 Tage.

## Aufgaben

1. Erstelle ein kurzes Testkonzept fuer den Campus Tech Shop.
2. Beschreibe zentrale Use Cases aus Sicht von Besucherinnen, Besuchern und Admins.
3. Erstelle Zustandsdiagramme und Zustandstabellen fuer ausgewaehlte Shop-Ablaufbereiche.
4. Leite Testfaelle aus dem beschriebenen Sollverhalten in `README.md`, Deinen Use Cases und Deinen Zustandsmodellen ab.
5. Automatisiere mindestens einen fachlich sinnvollen Testfall.
6. Dokumentiere gefundene Fehler mit Reproduktionsschritten, erwartetem Ergebnis, tatsaechlichem Ergebnis und Schweregrad.
7. Reflektiere kurz, welche Tests eher Unit-, Integrations-, API- oder Systemtests sind.

## Testkonzept

Dein Testkonzept soll kurz, aber konkret auf diese Anwendung bezogen sein. Es soll idealerweise enthalten:

- Testziele: Was willst Du mit Deinen Tests nachweisen oder aufdecken?
- Testobjekte: Welche Teile des Systems testest Du, z. B. Frontend, Backend-API, Warenkorb, Checkout, Admin-Bereich oder Datenbankverhalten?
- Testumfang und Abgrenzung: Was testest Du bewusst, und was testest Du nicht?
- Risiken und Prioritaeten: Welche Funktionen sind besonders fehleranfaellig oder fachlich wichtig?
- Teststufen: Welche Tests ordnest Du als Unit-, Integrations-, API- oder Systemtests ein?
- Testarten: Welche positiven Tests, negativen Tests, Grenzwerttests und rollenbezogenen Tests planst Du?
- Testdaten: Welche Produkte, Mengen, Rabattcodes, Login-Daten und Kundendaten verwendest Du?
- Testumgebung: Wie startest Du die Anwendung, setzt die Datenbank zurueck und fuehrst Tests aus?
- Abnahmekriterien: Wann ist Dein Testumfang aus Deiner Sicht ausreichend?

## Use Cases

Beschreibe mindestens drei Use Cases in Textform. Nutze dafuer jeweils einen klaren Aufbau:

- Name des Use Cases
- Akteur
- Vorbedingungen
- Hauptablauf
- Alternative Ablaeufe oder Fehlerfaelle
- Ergebnis/Nachbedingungen

Geeignete Use Cases sind zum Beispiel:

- Produkt suchen und in den Warenkorb legen
- Bestellung abschliessen
- Admin meldet sich an und bearbeitet ein Produkt

## Zustandsdiagramme und Zustandstabellen

Erstelle mindestens zwei Zustandsdiagramme und die passenden Zustandstabellen dazu. Du kannst sie als Bild, Mermaid-Diagramm, Tabelle in Markdown oder in einem anderen gut lesbaren Format abgeben.

Mindestens eines Deiner Modelle soll den Warenkorb- oder Checkout-Ablauf beschreiben. Ein weiteres Modell kann z. B. den Admin-Login, Produktstatus oder Bestellstatus beschreiben.

Eine Zustandstabelle soll mindestens enthalten:

- Zustand
- Ereignis/Aktion
- Bedingung
- Folgezustand
- Erwartetes Systemverhalten

Nutze die Modelle anschliessend, um konkrete Testfaelle abzuleiten. Achte besonders auf ungueltige Uebergaenge und Grenzfaelle.

## Automatisierter Testfall

Automatisiere mindestens einen Testfall. Empfohlen ist ein API-Test mit JUnit 5 und REST Assured, weil dieser Weg gut zu IntelliJ und Java passt. Du findest dafuer ein vorbereitetes Maven-Projekt im Ordner `java-api-tests`.

Du kannst ausserdem die Datei `api-tests/requests.http` verwenden, um API-Endpunkte schnell in IntelliJ auszuprobieren. Diese HTTP-Requests ersetzen aber nicht den automatisierten Pflicht-Testfall, sondern helfen Dir beim Erkunden und beim Ableiten Deiner Testfaelle.

Moegliche Werkzeuge sind:

- JUnit 5 und REST Assured fuer automatisierte API-Tests in Java
- IntelliJ HTTP Client fuer schnelle manuelle oder halbautomatisierte API-Pruefungen

Dein automatisierter Test soll:

- aus einem Use Case, einer Anforderung oder einem Zustandsmodell ableitbar sein,
- eine klare Erwartung pruefen,
- reproduzierbar mit `mvn test` im Ordner `java-api-tests` oder mit `npm test` ausfuehrbar sein,
- im Testbericht kurz erklaert werden.

## Erwartete Abgabe

- Testkonzept mit Testzielen, Testobjekten, Risiken, Testdaten und Teststufen.
- Mindestens drei beschriebene Use Cases.
- Mindestens zwei Zustandsdiagramme mit passenden Zustandstabellen.
- Abgeleitete Testfaelle inklusive erwarteter Ergebnisse.
- Mindestens ein automatisierter Testfall.
- Fehlerbericht mit Priorisierung.
- Kurze Reflexion zum Bezug auf bekannte Teststufen.

## Bewertungskriterien

- Nachvollziehbare Herleitung der Testfaelle aus Anforderungen, Use Cases und Zustandsmodellen.
- Sinnvolle Kombination von positiven Tests, negativen Tests und Grenzwerttests.
- Qualitaet und Lesbarkeit des automatisierten Tests.
- Praezision der Fehlerberichte.
- Angemessene Verwendung von Begriffen aus dem Softwaretesting.
- Klarer Bezug zwischen Testkonzept, Testmodellierung und tatsaechlicher Testdurchfuehrung.

## Rahmen

Du musst die Anwendung nicht reparieren. Falls Du Fehler behebst, trenne Tests, Befunde und Fixes klar voneinander.
